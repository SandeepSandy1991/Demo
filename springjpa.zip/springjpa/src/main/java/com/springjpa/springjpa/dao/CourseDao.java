package com.springjpa.springjpa.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springjpa.springjpa.entities.Course;

public interface CourseDao extends JpaRepository<Course, Long>{

}
