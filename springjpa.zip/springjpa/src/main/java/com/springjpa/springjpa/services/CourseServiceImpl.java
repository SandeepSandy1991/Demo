package com.springjpa.springjpa.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springjpa.springjpa.entities.Course;
import com.springjpa.springjpa.dao.CourseDao;

@Service
public class CourseServiceImpl implements CourseService {
	@Autowired
	private CourseDao courseDao;

	// List<Course> list;

	/*
	 * public CourseServiceImpl() {
	 * 
	 * list = new ArrayList<>(); list.add(new Course(145, "java Core Course",
	 * "this course contains basics of java")); list.add(new Course(2587,
	 * "Spring Boot Course", "creating Rest API using Spring Boot")); }
	 */

	@Override //get
	public List<Course> getCourses() {

		return courseDao.findAll() ;
	}

	@Override // get single id
	public Course getCourse(long courseId) {

		/*
		 * Course c = null; for (Course course : list) { if (course.getId() == courseId)
		 * { c = course; break; } }
		 */

		return courseDao.getReferenceById(courseId);
	}

	@Override // post
	public Course addCourse(Course course) {
		// list.add(course);
		return courseDao.save(course);
	}

	@Override // put
	public Course updateCourse(Course course) {
		/*
		 * list.forEach(e -> { if (e.getId() == course.getId()) {
		 * e.setDescription(course.getDescription()); e.setTitle(course.getTitle()); } }
		 * 
		 * );
		 */

		return courseDao.save(course);
	}

	@Override
	public void deleteCourse(long parseLong) {

		/*
		 * list=this.list.stream().filter(e->e.getId()!=parseLong).collect(Collectors.
		 * toList());
		 */
		Course entity =courseDao.getReferenceById(parseLong);
		courseDao.delete(entity);
	}

}